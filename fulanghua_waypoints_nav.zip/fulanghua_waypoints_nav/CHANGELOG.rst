^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package waypoints_navigation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* Implement the recovery operation of the Navigation system
* Add a service to clear costmaps
* Raise the version
* Delete the unnecessary comment
* Implemented the visualization marker
* Delete unnecessary message
* Move waypoints_navigation to the another directory
* Contributors: Daiki Maekawa, DaikiMaekawa
